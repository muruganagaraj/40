export interface viewmodel {
    itemId?: string;
    itemname?: string;
    price?: number;
    quantity?: number;
    amount?: number;    
}